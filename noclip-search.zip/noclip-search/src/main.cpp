#include <Geode/Geode.hpp>
#include <Geode/modify/LevelInfoLayer.hpp>

using namespace geode::prelude;

class $modify(NoclipSearchInfoLayer, LevelInfoLayer) {
	bool init(GJGameLevel* level, bool challenge) {
		if (!LevelInfoLayer::init(level, challenge)) return false;

		auto spr = CircleButtonSprite::createWithSpriteFrameName(
			"GJ_searchBtn_001.png", 1.0f,
			CircleBaseColor::Green, CircleBaseSize::Small
		);

		auto btn = CCMenuItemSpriteExtra::create(
			spr, this, menu_selector(NoclipSearchInfoLayer::onNoclipSearch)
		);
		btn->setID("noclip-search-button"_spr);

		// Put it in the left side menu (node IDs are provided by Geode)
		if (auto menu = this->getChildByID("left-side-menu")) {
			menu->addChild(btn);
			menu->updateLayout();
		} else {
			// Fallback in case the menu isn't found
			auto menu = CCMenu::create();
			menu->addChild(btn);
			auto winSize = CCDirector::sharedDirector()->getWinSize();
			menu->setPosition({ 30.f, winSize.height / 2.f });
			this->addChild(menu);
		}

		return true;
	}

	void onNoclipSearch(CCObject*) {
		std::string name = m_level->m_levelName;
		std::string query = name + " noclip";

		auto searchObj = GJSearchObject::create(SearchType::Search, query);
		auto scene = LevelBrowserLayer::scene(searchObj);
		CCDirector::sharedDirector()->pushScene(CCTransitionFade::create(0.5f, scene));
	}
};
